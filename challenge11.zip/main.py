def factorial(n):
  if n==0:
    return 1
  else:
    return n*factorial(n-1)
    #input a number
    num=int(input("enter a number:"))
    #check if the number is negative
    if num<0:
      print("factorial is not defind for negative number.")
    else:
      result=factorial(num)
      print(*f"the factorial of {num} is {result}")
      